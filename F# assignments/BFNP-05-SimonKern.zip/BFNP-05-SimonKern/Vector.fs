module Vector

type Vector =
  | V of float * float * float
  override v.ToString() =
    match v with
      V(x,y,z) -> "["+x.ToString()+","+y.ToString()+","+z.ToString()+"]"

let mkVector x y z = V(x, y, z);;
let getX (V(x,_,_)) = x;;
let getY (V(_,y,_)) = y;;
let getZ (V(_,_,z)) = z;;
let getCoord (V(x, y, z)) = (getX(V(x, y, z)), getY(V(x, y, z)), getZ(V(x, y, z)));;
let multScalar (V(x, y, z)) s = V(s*x, s*y, s*z);;
let magnitude (V(x, y, z)) = System.Math.Sqrt((getX(V(x, y, z))**2.0) + (getY(V(x, y, z))**2.0) + (getZ(V(x, y, z))**2.0));;
let dotProduct (V(vx, vy, vz)) (V(ux, uy, uz)) = (getX(V(ux, uy, uz))*getX(V(vx, vy, vz)))+(getY(V(ux, uy, uz))*getY(V(vx, vy, vz)))+(getZ(V(ux, uy, uz))*getZ(V(vx, vy, vz)));;
let crossProduct (V(vx, vy, vz)) (V(ux, uy, uz)) = V((getY(V(ux, uy, uz))*getZ(V(vx, vy, vz))-getZ(V(ux, uy, uz))*getY(V(vx, vy, vz))), (getZ(V(ux, uy, uz))*getX(V(vx, vy, vz))-getX(V(ux, uy, uz))*getZ(V(vx, vy, vz))), (getY(V(vx, vy, vz))*getX(V(ux, uy, uz))-getX(V(vx, vy, vz))*getY(V(ux, uy, uz))));;
let normalise (V(x,y,z) as v) = V(x/magnitude(v),y/magnitude(v),z/magnitude((v)));; // dno what do ?!
let round (V(x,y,z)) (d:int) = V(System.Math.Round(x,d),System.Math.Round(y,d),System.Math.Round(z,d));;

type Vector with
  static member ( ~- ) (V(x,y,z)) = V(-x,-y,-z)
  static member ( + ) (V(ux,uy,uz),V(vx,vy,vz)) = V(ux+vx,uy+vy,uz+vz)
  static member ( - ) (V(ux,uy,uz),V(vx,vy,vz)) = V(ux-vx,uy-vy,uz-vz)
  static member ( * ) (s,(V(x,y,z))) = multScalar (V(x,y,z)) s
  static member ( * ) (V(ux,uy,uz),(V(vx,vy,vz))) = dotProduct (V(vx,vy,vz)) (V(ux,uy,uz))
